# Exercício 7 – Vetor de registros

from dataclasses import dataclass

@dataclass
class Produto:
    codigo: int
    nome: str
    preco: float

produtos = [
    Produto(1, "Teclado", 120.00),
    Produto(2, "Mouse", 65.00),
    Produto(3, "Monitor", 850.00),
    Produto(4, "Headset", 150.00)
]

total = 0

for produto in produtos:
    print("Código:", produto.codigo)
    print("Nome:", produto.nome)
    print(f"Preço: R$ {produto.preco:.2f}")
    print()

    total = total + produto.preco

print(f"Valor total dos produtos: R$ {total:.2f}")
