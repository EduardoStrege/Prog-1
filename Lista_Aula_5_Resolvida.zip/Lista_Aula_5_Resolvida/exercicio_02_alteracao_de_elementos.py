# Exercício 2 – Alteração de elementos

valores = [5, 10, 15, 20, 25]

for indice in range(len(valores)):
    valores[indice] = valores[indice] * 2

print("Lista modificada:", valores)
