# Lista de Exercícios – Aula 5 | Soluções em Python
# Os exercícios estão separados por comentários.

#################################################################
# Exercício 1 – Vetor de notas

notas = [7.5, 8.0, 6.5, 9.0, 5.5, 8.5]

soma = 0
maior_nota = notas[0]

print("Notas dos alunos:")

for nota in notas:
    print(nota)
    soma = soma + nota

    if nota > maior_nota:
        maior_nota = nota

media = soma / len(notas)

print("Média das notas:", media)
print("Maior nota:", maior_nota)


#################################################################
# Exercício 2 – Alteração de elementos

valores = [5, 10, 15, 20, 25]

for indice in range(len(valores)):
    valores[indice] = valores[indice] * 2

print("Lista modificada:", valores)


#################################################################
# Exercício 3 – Busca em um vetor

numeros = [12, 5, 8, 20, 15, 8, 30, 4]

numero = int(input("Digite um número para buscar: "))

encontrado = False

for indice in range(len(numeros)):
    if numeros[indice] == numero:
        print("Número encontrado na posição:", indice)
        encontrado = True
        break

if encontrado == False:
    print("Número não encontrado na lista.")


#################################################################
# Exercício 4 – Matriz 3 x 3

matriz = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

for linha in range(3):
    for coluna in range(3):
        print(matriz[linha][coluna], end=" ")
    print()


#################################################################
# Exercício 5 – Soma de uma matriz

matriz = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

soma = 0

for linha in range(3):
    for coluna in range(3):
        soma = soma + matriz[linha][coluna]

print("Soma de todos os elementos:", soma)


#################################################################
# Exercício 6 – Registro com dicionário

aluno = {
    "matricula": 12345,
    "nome": "João",
    "cra": 8.5,
    "ativo": True
}

print("Registro original:")
print(aluno)

aluno["cra"] = 9.0

print("\nRegistro após a alteração do CRA:")
print(aluno)


#################################################################
# Exercício 7 – Vetor de registros

from dataclasses import dataclass

@dataclass
class Produto:
    codigo: int
    nome: str
    preco: float

produtos = [
    Produto(1, "Teclado", 120.00),
    Produto(2, "Mouse", 65.00),
    Produto(3, "Monitor", 850.00),
    Produto(4, "Headset", 150.00)
]

total = 0

for produto in produtos:
    print("Código:", produto.codigo)
    print("Nome:", produto.nome)
    print(f"Preço: R$ {produto.preco:.2f}")
    print()

    total = total + produto.preco

print(f"Valor total dos produtos: R$ {total:.2f}")


#################################################################
# Exercício 8 – Tratamento de erros

lista = [10, 20, 30]
dicionario = {
    "nome": "Maria",
    "idade": 20
}

try:
    print(lista[5])
except IndexError:
    print("Erro: o índice informado não existe na lista.")

try:
    print(dicionario["curso"])
except KeyError:
    print("Erro: a chave informada não existe no dicionário.")


#################################################################
# Desafio opcional – Matriz de notas

# Cada linha representa um aluno.
# Cada coluna representa uma avaliação.

notas = [
    [8.0, 7.5, 9.0],
    [6.0, 7.0, 8.0],
    [9.5, 9.0, 8.5],
    [5.0, 6.5, 7.0]
]

maior_media = 0
aluno_maior_media = 0

for linha in range(len(notas)):
    soma = 0

    for coluna in range(len(notas[linha])):
        soma = soma + notas[linha][coluna]

    media = soma / len(notas[linha])

    print(f"Média do aluno {linha + 1}: {media:.2f}")

    if media > maior_media:
        maior_media = media
        aluno_maior_media = linha + 1

print(f"Maior média: {maior_media:.2f}")
print(f"Aluno com a maior média: {aluno_maior_media}")

