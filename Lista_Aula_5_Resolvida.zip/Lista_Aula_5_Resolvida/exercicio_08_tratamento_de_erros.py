# Exercício 8 – Tratamento de erros

lista = [10, 20, 30]
dicionario = {
    "nome": "Maria",
    "idade": 20
}

try:
    print(lista[5])
except IndexError:
    print("Erro: o índice informado não existe na lista.")

try:
    print(dicionario["curso"])
except KeyError:
    print("Erro: a chave informada não existe no dicionário.")
