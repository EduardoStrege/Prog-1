# Exercício 1 – Vetor de notas

notas = [7.5, 8.0, 6.5, 9.0, 5.5, 8.5]

soma = 0
maior_nota = notas[0]

print("Notas dos alunos:")

for nota in notas:
    print(nota)
    soma = soma + nota

    if nota > maior_nota:
        maior_nota = nota

media = soma / len(notas)

print("Média das notas:", media)
print("Maior nota:", maior_nota)
