# Exercício 3 – Busca em um vetor

numeros = [12, 5, 8, 20, 15, 8, 30, 4]

numero = int(input("Digite um número para buscar: "))

encontrado = False

for indice in range(len(numeros)):
    if numeros[indice] == numero:
        print("Número encontrado na posição:", indice)
        encontrado = True
        break

if encontrado == False:
    print("Número não encontrado na lista.")
