# Exercício 6 – Registro com dicionário

aluno = {
    "matricula": 12345,
    "nome": "João",
    "cra": 8.5,
    "ativo": True
}

print("Registro original:")
print(aluno)

aluno["cra"] = 9.0

print("\nRegistro após a alteração do CRA:")
print(aluno)
