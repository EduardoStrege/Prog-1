# Desafio opcional – Matriz de notas

# Cada linha representa um aluno.
# Cada coluna representa uma avaliação.

notas = [
    [8.0, 7.5, 9.0],
    [6.0, 7.0, 8.0],
    [9.5, 9.0, 8.5],
    [5.0, 6.5, 7.0]
]

maior_media = 0
aluno_maior_media = 0

for linha in range(len(notas)):
    soma = 0

    for coluna in range(len(notas[linha])):
        soma = soma + notas[linha][coluna]

    media = soma / len(notas[linha])

    print(f"Média do aluno {linha + 1}: {media:.2f}")

    if media > maior_media:
        maior_media = media
        aluno_maior_media = linha + 1

print(f"Maior média: {maior_media:.2f}")
print(f"Aluno com a maior média: {aluno_maior_media}")
