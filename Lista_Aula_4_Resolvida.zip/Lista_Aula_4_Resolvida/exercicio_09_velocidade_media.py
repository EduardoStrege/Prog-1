# Exercício 9 – Cálculo de velocidade média

distancia = float(input("Digite a distância percorrida em quilômetros: "))
tempo = float(input("Digite o tempo em horas: "))

if tempo == 0:
    print("Não é possível calcular: o tempo não pode ser zero.")
else:
    velocidade = distancia / tempo
    print(f"Velocidade média: {velocidade:.2f} km/h")
