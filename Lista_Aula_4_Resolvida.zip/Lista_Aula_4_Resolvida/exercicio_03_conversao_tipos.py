# Exercício 3 – Conversão de tipos

valor = input("Digite um valor numérico inteiro: ")

valor_int = int(valor)
valor_float = float(valor)

print("Valor como inteiro:", valor_int)
print("Tipo:", type(valor_int))

print("Valor como float:", valor_float)
print("Tipo:", type(valor_float))
