# Lista de Exercícios – Aula 4 | Soluções em Python
# Cada exercício está separado por comentários.


=================================================================
# Exercício 1 – Dados pessoais

nome = input("Digite seu nome: ")
idade = int(input("Digite sua idade: "))
altura = float(input("Digite sua altura em metros: "))

print("\nDados pessoais")
print("Nome:", nome)
print("Idade:", idade)
print("Altura:", altura)

print("\nTipos das variáveis")
print("Tipo do nome:", type(nome))
print("Tipo da idade:", type(idade))
print("Tipo da altura:", type(altura))


=================================================================
# Exercício 2 – Operações com inteiros

numero1 = int(input("Digite o primeiro número inteiro: "))
numero2 = int(input("Digite o segundo número inteiro: "))

print("Soma:", numero1 + numero2)
print("Subtração:", numero1 - numero2)
print("Multiplicação:", numero1 * numero2)

if numero2 != 0:
    print("Divisão inteira:", numero1 // numero2)
    print("Resto da divisão:", numero1 % numero2)
else:
    print("Não é possível dividir por zero.")

print("Potência:", numero1 ** numero2)


=================================================================
# Exercício 3 – Conversão de tipos

valor = input("Digite um valor numérico inteiro: ")

valor_int = int(valor)
valor_float = float(valor)

print("Valor como inteiro:", valor_int)
print("Tipo:", type(valor_int))

print("Valor como float:", valor_float)
print("Tipo:", type(valor_float))


=================================================================
# Exercício 4 – Compra simples

preco = float(input("Digite o preço do produto: "))
quantidade = int(input("Digite a quantidade comprada: "))

total = preco * quantidade

print(f"Valor total da compra: R$ {total:.2f}")


=================================================================
# Exercício 5 – Média de notas

nota1 = float(input("Digite a primeira nota: "))
nota2 = float(input("Digite a segunda nota: "))
nota3 = float(input("Digite a terceira nota: "))

media = (nota1 + nota2 + nota3) / 3

print(f"Média: {media:.2f}")

if media >= 7.0:
    print("Aprovado.")
else:
    print("Média menor que 7.0.")


=================================================================
# Exercício 6 – Caracteres e strings

texto = input("Digite uma palavra ou nome: ")

print("Texto digitado:", texto)
print("Quantidade de caracteres:", len(texto))

if len(texto) > 0:
    print("Primeiro caractere:", texto[0])
    print("Último caractere:", texto[-1])
else:
    print("Nenhum caractere foi digitado.")


=================================================================
# Exercício 7 – Conversão de temperatura

celsius = float(input("Digite a temperatura em graus Celsius: "))

fahrenheit = (celsius * 9 / 5) + 32

print(f"Temperatura em Celsius: {celsius:.2f} °C")
print(f"Temperatura em Fahrenheit: {fahrenheit:.2f} °F")


=================================================================
# Exercício 8 – Divisão segura

numero1 = float(input("Digite o primeiro número: "))
numero2 = float(input("Digite o segundo número: "))

if numero2 == 0:
    print("A divisão não pode ser realizada, pois o segundo número é zero.")
else:
    resultado = numero1 / numero2
    print("Resultado da divisão:", resultado)


=================================================================
# Exercício 9 – Cálculo de velocidade média

distancia = float(input("Digite a distância percorrida em quilômetros: "))
tempo = float(input("Digite o tempo em horas: "))

if tempo == 0:
    print("Não é possível calcular: o tempo não pode ser zero.")
else:
    velocidade = distancia / tempo
    print(f"Velocidade média: {velocidade:.2f} km/h")


=================================================================
# Exercício 10 – Desafio: conversão e cálculo

preco_texto = input("Digite o preço do produto: ")
quantidade_texto = input("Digite a quantidade comprada: ")

preco = float(preco_texto)
quantidade = int(quantidade_texto)

total = preco * quantidade

percentual_desconto = float(input("Digite o percentual de desconto: "))

valor_desconto = total * percentual_desconto / 100
valor_final = total - valor_desconto

print(f"Preço unitário: R$ {preco:.2f}")
print("Quantidade:", quantidade)
print(f"Valor da compra: R$ {total:.2f}")
print(f"Desconto: {percentual_desconto:.2f}% (R$ {valor_desconto:.2f})")
print(f"Valor final: R$ {valor_final:.2f}")

