# Exercício 1 – Dados pessoais

nome = input("Digite seu nome: ")
idade = int(input("Digite sua idade: "))
altura = float(input("Digite sua altura em metros: "))

print("\nDados pessoais")
print("Nome:", nome)
print("Idade:", idade)
print("Altura:", altura)

print("\nTipos das variáveis")
print("Tipo do nome:", type(nome))
print("Tipo da idade:", type(idade))
print("Tipo da altura:", type(altura))
