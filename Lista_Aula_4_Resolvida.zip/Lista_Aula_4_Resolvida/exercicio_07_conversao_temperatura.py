# Exercício 7 – Conversão de temperatura

celsius = float(input("Digite a temperatura em graus Celsius: "))

fahrenheit = (celsius * 9 / 5) + 32

print(f"Temperatura em Celsius: {celsius:.2f} °C")
print(f"Temperatura em Fahrenheit: {fahrenheit:.2f} °F")
