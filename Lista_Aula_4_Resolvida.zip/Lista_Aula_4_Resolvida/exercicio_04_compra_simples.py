# Exercício 4 – Compra simples

preco = float(input("Digite o preço do produto: "))
quantidade = int(input("Digite a quantidade comprada: "))

total = preco * quantidade

print(f"Valor total da compra: R$ {total:.2f}")
