# Exercício 8 – Divisão segura

numero1 = float(input("Digite o primeiro número: "))
numero2 = float(input("Digite o segundo número: "))

if numero2 == 0:
    print("A divisão não pode ser realizada, pois o segundo número é zero.")
else:
    resultado = numero1 / numero2
    print("Resultado da divisão:", resultado)
