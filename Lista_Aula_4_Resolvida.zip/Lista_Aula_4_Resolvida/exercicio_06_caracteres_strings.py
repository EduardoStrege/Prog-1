# Exercício 6 – Caracteres e strings

texto = input("Digite uma palavra ou nome: ")

print("Texto digitado:", texto)
print("Quantidade de caracteres:", len(texto))

if len(texto) > 0:
    print("Primeiro caractere:", texto[0])
    print("Último caractere:", texto[-1])
else:
    print("Nenhum caractere foi digitado.")
