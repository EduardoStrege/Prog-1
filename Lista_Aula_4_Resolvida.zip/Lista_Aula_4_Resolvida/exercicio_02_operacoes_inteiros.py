# Exercício 2 – Operações com inteiros

numero1 = int(input("Digite o primeiro número inteiro: "))
numero2 = int(input("Digite o segundo número inteiro: "))

print("Soma:", numero1 + numero2)
print("Subtração:", numero1 - numero2)
print("Multiplicação:", numero1 * numero2)

if numero2 != 0:
    print("Divisão inteira:", numero1 // numero2)
    print("Resto da divisão:", numero1 % numero2)
else:
    print("Não é possível dividir por zero.")

print("Potência:", numero1 ** numero2)
