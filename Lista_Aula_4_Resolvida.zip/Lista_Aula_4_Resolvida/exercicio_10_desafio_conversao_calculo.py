# Exercício 10 – Desafio: conversão e cálculo

preco_texto = input("Digite o preço do produto: ")
quantidade_texto = input("Digite a quantidade comprada: ")

preco = float(preco_texto)
quantidade = int(quantidade_texto)

total = preco * quantidade

percentual_desconto = float(input("Digite o percentual de desconto: "))

valor_desconto = total * percentual_desconto / 100
valor_final = total - valor_desconto

print(f"Preço unitário: R$ {preco:.2f}")
print("Quantidade:", quantidade)
print(f"Valor da compra: R$ {total:.2f}")
print(f"Desconto: {percentual_desconto:.2f}% (R$ {valor_desconto:.2f})")
print(f"Valor final: R$ {valor_final:.2f}")
